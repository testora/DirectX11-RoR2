#pragma once
#include "Engine_Define.h"

BEGIN(Engine)

class C$safeitemname$
{

};

END
