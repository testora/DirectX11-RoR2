#pragma once
#include "Client_Define.h"

BEGIN(Client)

class C$safeitemname$
{

};

END
